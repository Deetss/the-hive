import math
from PIL import Image

im = Image.open('abathur-ref.png').convert('RGBA')
W,H = im.size
px = im.load()
BG=(239,9,198)
def is_bg(r,g,b):
    return (abs(r-BG[0])<40 and abs(g-BG[1])<45 and abs(b-BG[2])<45) or (r>195 and g<70 and b>150)
keyed=0
for y in range(H):
    for x in range(W):
        r,g,b,a = px[x,y]
        if is_bg(r,g,b):
            px[x,y]=(0,0,0,0); keyed+=1
print('keyed px', keyed, 'of', W*H)
bbox=im.getbbox(); print('bbox',bbox)
im=im.crop(bbox)
TH=72; tw=round(im.width*TH/im.height)
sprite=im.resize((tw,TH),Image.LANCZOS)
sp=sprite.load()
# despeckle magenta fringe + harden alpha
for y in range(TH):
    for x in range(tw):
        r,g,b,a=sp[x,y]
        if is_bg(r,g,b): a=0
        sp[x,y]=(r,g,b,0 if a<115 else 255)
sprite.save('coiled_sprite.png'); print('sprite',sprite.size)

def env_planted(t): return 1 - t**3
def strip(sprite,amp,wl,nf=8):
    W,H=sprite.size; pad=amp+2; frames=[]
    for f in range(nf):
        ph=2*math.pi*f/nf
        c=Image.new('RGBA',(W+pad*2,H+4),(0,0,0,0))
        for y in range(H):
            t=y/(H-1)
            dx=round(amp*env_planted(t)*math.sin(2*math.pi*y/wl-ph))
            c.alpha_composite(sprite.crop((0,y,W,y+1)),(pad+dx,y+2))
        frames.append(c)
    return frames
variants={'coil_amp7_wl40':strip(sprite,7,40),'coil_amp10_wl46':strip(sprite,10,46),'coil_amp13_wl52':strip(sprite,13,52)}
SCALE=3;bg=(40,42,54,255);NF=8
cw=max(f.width for v in variants.values() for f in v);ch=max(f.height for v in variants.values() for f in v);gap=6
gw=cw*NF+gap*(NF+1);gh=ch*len(variants)+gap*(len(variants)+1)
grid=Image.new('RGBA',(gw,gh),bg)
for ri,(n,fr) in enumerate(variants.items()):
    for ci,f in enumerate(fr):
        grid.alpha_composite(f,(gap+ci*(cw+gap)+(cw-f.width)//2,gap+ri*(ch+gap)))
grid=grid.resize((gw*SCALE,gh*SCALE),Image.NEAREST);grid.save('coiled_variants.png');print('grid',grid.size)
for n in variants:
    fr=[f.resize((f.width*SCALE,f.height*SCALE),Image.NEAREST) for f in variants[n]]
    flat=[Image.alpha_composite(Image.new('RGBA',f.size,bg),f).convert('P',palette=Image.ADAPTIVE) for f in fr]
    flat[0].save(f'gif_{n}.gif',save_all=True,append_images=flat[1:],duration=90,loop=0,disposal=2)
