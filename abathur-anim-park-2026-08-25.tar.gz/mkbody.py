import sys, json, base64
# args: out.json  W H seed strength prompt  [init.png]
out,W,H,seed,strength,prompt = sys.argv[1:7]
init = sys.argv[7] if len(sys.argv)>7 else None
b={"model":"FLUX.2-pro","prompt":prompt,"width":int(W),"height":int(H),
   "output_format":"png","seed":int(seed)}
if init:
    b["input_image"]=base64.b64encode(open(init,'rb').read()).decode()
    b["strength"]=float(strength)
json.dump(b,open(out,'w'))
print("body bytes", len(open(out).read()), "init" if init else "txt2img")
