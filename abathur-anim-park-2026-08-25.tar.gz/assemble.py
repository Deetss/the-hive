import numpy as np
from PIL import Image
import pixelate as px

srcs=['pose_fullleft2.png','pose_midleft2.png','probe_left.png']  # strong-left, mild-left, cobra
raws=[Image.open(s).convert('RGBA') for s in srcs]
BG=(236,17,186)

def opaque(im):
    a=np.asarray(im.convert('RGBA'),float); rgb=a[...,:3]
    d=np.sqrt(((rgb-np.array(BG))**2).sum(-1)); return rgb[d>95]
cent=px._kmeans_centroids(np.concatenate([opaque(im) for im in raws]),20,seed=1)
PAL=[tuple(int(v) for v in c) for c in np.rint(cent)]

def norm(im):
    s=px.quantize_to_grid(im,120,keep_aspect=True,downscale_filter=Image.BOX)
    s=px.key_background(s,key=BG,tol=95,flood=False)   # KEY FIRST (bg still magenta)
    s=px.snap_palette_fixed(s,PAL)                    # then snap only opaque pixels
    s=px.despeckle_alpha(s)
    return s
frames=[norm(im) for im in raws]

def bbox(im):
    a=np.asarray(im)[...,3]; ys,xs=np.where(a>0); return xs.min(),ys.min(),xs.max()+1,ys.max()+1
crop=[im.crop(bbox(im)) for im in frames]
Wc=max(c.width for c in crop); Hc=max(c.height for c in crop)
def place(c):
    cv=Image.new('RGBA',(Wc+8,Hc+4),(0,0,0,0)); cv.alpha_composite(c,((Wc+8-c.width)//2,(Hc+4)-c.height)); return cv
canv=[place(c) for c in crop]
mir=[c.transpose(Image.FLIP_LEFT_RIGHT) for c in canv]
# sway loop: strongL, mildL, cobra, mildL, [mirror] mildR, cobraR, strongR, mildR
seq=[canv[0],canv[1],canv[2],canv[1],mir[0],mir[1],mir[2],mir[1]]

def strip(seq,fn,S=4):
    bg=(40,42,54,255); gap=6
    gw=(canv[0].width*S+gap)*len(seq)+gap
    g=Image.new('RGBA',(gw,canv[0].height*S+2*gap),bg)
    for i,f in enumerate(seq):
        g.alpha_composite(f.resize((f.width*S,f.height*S),Image.NEAREST),(gap+i*(canv[0].width*S+gap),gap))
    g.convert('RGB').save(fn)
strip(seq,'cobra_strip.png')
S=4;bg=(40,42,54,255)
flat=[Image.alpha_composite(Image.new('RGBA',(f.width*S,f.height*S),bg),f.resize((f.width*S,f.height*S),Image.NEAREST)).convert('P',palette=Image.ADAPTIVE) for f in seq]
flat[0].save('cobra_loop.gif',save_all=True,append_images=flat[1:],duration=110,loop=0,disposal=2)
print('ok frames',len(seq),'cell',canv[0].size)
