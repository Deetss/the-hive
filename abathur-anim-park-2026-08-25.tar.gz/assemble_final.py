import numpy as np
from PIL import Image
import pixelate as px

srcs=['pose_center2.png','pose_midleft2.png','pose_fullleft2.png']
raws=[Image.open(s).convert('RGBA') for s in srcs]
BG=(236,17,186)
def opaque(im):
    a=np.asarray(im.convert('RGBA'),float); rgb=a[...,:3]
    d=np.sqrt(((rgb-np.array(BG))**2).sum(-1)); return rgb[d>120]
PAL=[tuple(int(v) for v in c) for c in np.rint(px._kmeans_centroids(np.concatenate([opaque(im) for im in raws]),22,seed=1))]

GRID=60
def norm(im):
    s=px.quantize_to_grid(im,GRID,keep_aspect=True,downscale_filter=Image.BOX)
    s=px.key_background(s,key=BG,tol=140,flood=False)  # higher tol = defringe magenta halo
    s=px.snap_palette_fixed(s,PAL)
    s=px.despeckle_alpha(s)
    return s
frames=[norm(im) for im in raws]
def bbox(im):
    a=np.asarray(im)[...,3]; ys,xs=np.where(a>0); return xs.min(),ys.min(),xs.max()+1,ys.max()+1
crop=[im.crop(bbox(im)) for im in frames]
Wc=max(c.width for c in crop); Hc=max(c.height for c in crop)
def place(c):
    cv=Image.new('RGBA',(Wc+4,Hc+2),(0,0,0,0)); cv.alpha_composite(c,((Wc+4-c.width)//2,(Hc+2)-c.height)); return cv
C,M,F=[place(c) for c in crop]
mir=lambda im: im.transpose(Image.FLIP_LEFT_RIGHT)
seq=[C,M,F,M, mir(C),mir(M),mir(F),mir(M)]
fw,fh=seq[0].size
sheet=Image.new('RGBA',(fw*len(seq),fh),(0,0,0,0))
for i,f in enumerate(seq): sheet.alpha_composite(f,(i*fw,0))
out='/home/deetss/dev/personal/the-hive/src/renderer/src/assets/zerg/abathur-slither.png'
sheet.save(out)
print('SHEET',sheet.size,'frame',(fw,fh),'->',out)
# preview strip x4
S=4;bg=(40,42,54,255);gap=6
g=Image.new('RGBA',((fw*S+gap)*len(seq)+gap,fh*S+2*gap),bg)
for i,f in enumerate(seq): g.alpha_composite(f.resize((fw*S,fh*S),Image.NEAREST),(gap+i*(fw*S+gap),gap))
g.convert('RGB').save('final_strip.png')
flat=[Image.alpha_composite(Image.new('RGBA',(fw*S,fh*S),bg),f.resize((fw*S,fh*S),Image.NEAREST)).convert('P',palette=Image.ADAPTIVE) for f in seq]
flat[0].save('final_loop.gif',save_all=True,append_images=flat[1:],duration=110,loop=0,disposal=2)
print('previews: final_strip.png final_loop.gif')
