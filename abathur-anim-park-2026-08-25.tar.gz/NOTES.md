# Abathur slither animation — parked WIP (2026-08-25)

> NOTE: internal Foundry endpoint scrubbed to ${FLUX_HOST}. Set it from KeePass before running gen scripts.

## What this is
Attempt to generate a genuine (non-warp) slither animation for Abathur via the
Bloomfield Azure FLUX.2-pro endpoint, then run it through a custom pixel-art
post pipeline (pixelate.py).

## KEY FINDING (why parked)
This FLUX endpoint's img2img does NOT preserve the coiled-crown Abathur identity
through pose changes — `strength` is effectively ignored, so every img2img call
"reimagines" toward a generic cobra-serpent. Same-seed frames are consistent
WITH EACH OTHER (usable cobra loop) but drift OFF the reference (official Abathur:
coiled base, bladed crown, green eye clusters). User's blocker: not close enough
to the reference. ~$34 of endpoint spend confirmed this ceiling.

## Files
- pixelate.py        - KEEPER. True-pixel-art pipeline (also copied to repo tools/).
                       grid quantize (BOX) -> palette snap (kmeans/fixed) -> alpha key
                       (flood/all) -> tileable check/enforce -> nearest upscale.
                       Gotcha: KEY BEFORE fixed-palette-snap, else bg snaps to a
                       creature color and can't be keyed. Use flood=False to kill
                       magenta trapped inside coils. numpy required (pip install numpy).
- mkbody.py          - builds FLUX JSON payload (base64 init inline; avoids jq arg cap)
- gen.sh, finalize.py, rig.py, build_coiled.py, slither_preview.py, assemble*.py - gens/experiments
- abathur-ref.png    - the GOOD on-model coiled Abathur (reference-guided gen, magenta bg)
- init256.png        - keyed Abathur on magenta, 256sq (img2img init that kept drifting)
- pose_*.png         - the generated frames ($34): center/midleft/fullleft variants, probe_left
- slither_sheet_raw.png - the 2x2 "cycle" that FLUX drew as 4 near-identical poses (dead end)
- final_loop.gif / cobra_loop.gif - the assembled 8-frame cobra loops (user: "terrible"/"closer")
- final_strip.png, *_compare.png - review strips

## Endpoint contract (works)
POST ${FLUX_HOST}/providers/blackforestlabs/v1/flux-2-pro?api-version=preview
Auth: Bearer (az account get-access-token --scope https://cognitiveservices.azure.com/.default)
Body: {model:"FLUX.2-pro", prompt, width, height, output_format:"png", seed, input_image(b64,no prefix), strength}
Cost: request_meta.cost ~3.0 (txt2img 1MP) / ~4.5 (img2img, flat regardless of size). Likely USD.
Text-only PASSES content-safety; img2img from OUR clean pixel sprite also passes (raw Blizzard art refused).

## RECOMMENDED NEXT (stay on-reference)
1. Retro Diffusion advanced-animation on the reference sprite (BEST, purpose-built,
   animates the actual sprite so it can't drift). Needs user's rdpk- API key (not in env).
   REST: POST https://api.retrodiffusion.ai/v1  header X-RD-Token: rdpk-...
   style rd_advanced_animation__custom_action, input_image=refs/zerg/abathur-upload.png,
   prompt describes MOTION only, frames_duration 8, return_spritesheet true. ~$0.25/anim.
   (prep done: refs/zerg/abathur-upload.png + -rgb.png already exist.)
2. FREE fallback: segmented/cutout rig on the coiled reference sprite (rig.py first pass).
   Guaranteed on-model (it IS the reference), genuine articulation, but reads as a
   writhe+blade-whip, not a ground-slither.

## Wiring target (when frames are approved)
src/renderer/src/scene/office/zergCast.ts -> loadSlitherFrames(): replace the warp
math with: slice a horizontal sprite sheet into N frames, return [seq,seq,seq].
CharacterSprite continuous mode loops frames[0]. Sheet goes in assets/zerg/.
A rejected sheet abathur-slither.png (456x48, 8f) is currently in assets/zerg/ — replace it.
