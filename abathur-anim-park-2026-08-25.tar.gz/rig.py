import math
from PIL import Image

# --- load + chroma-key the on-model coiled Abathur ---
im=Image.open('abathur-ref.png').convert('RGBA'); W,H=im.size; px=im.load()
BG=(239,9,198)
def is_bg(r,g,b):
    return (abs(r-BG[0])<40 and abs(g-BG[1])<45 and abs(b-BG[2])<45) or (r>195 and g<70 and b>150)
for y in range(H):
    for x in range(W):
        r,g,b,a=px[x,y]
        if is_bg(r,g,b): px[x,y]=(0,0,0,0)
im=im.crop(im.getbbox())
Wc,Hc=im.size
print('content',Wc,Hc)

# --- cut into 3 rigid bands with slight vertical overlap to hide seams ---
# fractions of height (0=top): head/blades, torso, coil-base(static)
B_head=(0.00,0.34); B_torso=(0.30,0.66); B_coil=(0.62,1.00)
def band(f0,f1):
    y0=int(f0*Hc); y1=int(f1*Hc)
    return im.crop((0,y0,Wc,y1)), y0, y1
head,hy0,hy1 = band(*B_head)
torso,ty0,ty1= band(*B_torso)
coil,cy0,cy1 = band(*B_coil)

cx = Wc//2  # body centerline x

def rot_about_bottom(strip, deg):
    # rotate about bottom-center; return image + (bottomcenter x,y) in new image coords
    w,h=strip.size
    big=Image.new('RGBA',(w*2,h*2),(0,0,0,0))
    big.alpha_composite(strip,(w//2, h//2))
    bcx,bcy = w//2 + w//2, h//2 + h  # bottom-center of strip in big
    r=big.rotate(deg, resample=Image.BICUBIC, center=(bcx,bcy), expand=True)
    # after expand, bottom-center pivot maps to... compute via rotate math is messy;
    # easier: rotate with center and expand=False on a big padded canvas so pivot stays put
    r2=big.rotate(deg, resample=Image.BICUBIC, center=(bcx,bcy), expand=False)
    return r2,(bcx,bcy)

def frame(t):
    ph=2*math.pi*t
    th1=math.radians(7*math.sin(ph))               # torso about coil-top joint
    th2=math.radians(11*math.sin(ph-1.15))         # head about torso-top joint (lag=whip)
    bob=2*math.sin(ph*1.0)
    # canvas
    cw,chh=Wc*2, Hc*2
    canv=Image.new('RGBA',(cw,chh),(0,0,0,0))
    # base coil static: place so its bottom sits at canvas bottom-center anchor
    ax, ay = cw//2, chh-4                           # anchor (feet)
    canv.alpha_composite(coil,(ax-coil.width//2, ay-coil.height))
    joint0=(ax, ay-coil.height+ int(0.05*Hc))       # coil-top joint (small overlap)
    # torso rotated about joint0
    tr,(tpx,tpy)=rot_about_bottom(torso, math.degrees(th1))
    canv.alpha_composite(tr,(joint0[0]-tpx, int(joint0[1]-tpy - bob)))
    # torso-top joint in canvas coords: rotate vector (0,-torso.height) by th1 from joint0
    thh=torso.height
    j1x=joint0[0]+ math.sin(th1)*(-thh)*-1          # x' = jx + sin(th1)*(-(-h))... compute properly:
    # vector up = (0,-thh); rotate by th1 (CCW positive in PIL? rotate deg CCW). Use standard:
    vx,vy=0,-thh
    rx= vx*math.cos(th1)-vy*math.sin(th1)
    ry= vx*math.sin(th1)+vy*math.cos(th1)
    j1=(joint0[0]+rx, joint0[1]+ry - bob)
    # head rotated about its bottom by th1+th2
    hr,(hpx,hpy)=rot_about_bottom(head, math.degrees(th1+th2))
    canv.alpha_composite(hr,(int(j1[0]-hpx), int(j1[1]-hpy)))
    return canv, (ax,ay)

# render 8 frames, autocrop to common bbox, downscale
raws=[]; NF=8
for i in range(NF):
    c,anchor=frame(i/NF); raws.append((c,anchor))
# common content bbox across frames
bb=None
for c,_ in raws:
    b=c.getbbox()
    bb=b if bb is None else (min(bb[0],b[0]),min(bb[1],b[1]),max(bb[2],b[2]),max(bb[3],b[3]))
TH=52
scale=TH/(bb[3]-bb[1])
frames=[]
for c,anchor in raws:
    cc=c.crop(bb)
    fw=round(cc.width*scale)
    f=cc.resize((fw,TH),Image.LANCZOS)
    # harden alpha
    fp=f.load()
    for y in range(f.height):
        for x in range(f.width):
            r,g,b,a=fp[x,y]; fp[x,y]=(r,g,b,0 if a<115 else 255)
    frames.append(f)
print('frame size', frames[0].size)

# preview strip + gif
S=5; bgc=(40,42,54,255); gap=6
cw=max(f.width for f in frames); ch=max(f.height for f in frames)
gw=cw*NF+gap*(NF+1)
grid=Image.new('RGBA',(gw,ch+2*gap),bgc)
for ci,f in enumerate(frames): grid.alpha_composite(f,(gap+ci*(cw+gap)+(cw-f.width)//2, gap+(ch-f.height)))
grid=grid.resize((gw*S,(ch+2*gap)*S),Image.NEAREST); grid.save('rig_strip.png'); print('strip',grid.size)
flat=[Image.alpha_composite(Image.new('RGBA',(cw*S,ch*S),bgc), f.resize((f.width*S,f.height*S),Image.NEAREST)).convert('P',palette=Image.ADAPTIVE) for f in frames]
flat[0].save('rig.gif',save_all=True,append_images=flat[1:],duration=90,loop=0,disposal=2)
