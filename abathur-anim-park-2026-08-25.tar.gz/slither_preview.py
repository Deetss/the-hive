import math
from PIL import Image

src = Image.open('/home/deetss/dev/personal/the-hive/src/renderer/src/assets/zerg/abathur.png').convert('RGBA')
W,H = src.size
NF = 8

def envelope(kind, t):  # t: 0=top/head .. 1=bottom/tail
    if kind=='head':      # cobra sway: head moves most
        return 1 - t
    if kind=='planted':   # tail planted, whole body undulates
        return 1 - t**3
    if kind=='midpeak':   # writhe through the middle
        return math.sin(math.pi*(1-t))**0.7
    return 1

def make(amp, wl, env, bob=0):
    pad = amp+2
    frames=[]
    for f in range(NF):
        phase = 2*math.pi*f/NF
        canvas = Image.new('RGBA',(W+pad*2, H+4),(0,0,0,0))
        yb = round(bob*math.sin(phase))
        for y in range(H):
            t = y/(H-1)
            dx = round(amp*env(kind_for(env),t)*math.sin(2*math.pi*y/wl - phase))
            row = src.crop((0,y,W,y+1))
            canvas.alpha_composite(row,(pad+dx, y+2+yb))
        frames.append(canvas)
    return frames

# hack: pass env kind as string
def kind_for(k): return k

def make2(amp, wl, kind, bob=0):
    pad = amp+2
    frames=[]
    for f in range(NF):
        phase = 2*math.pi*f/NF
        canvas = Image.new('RGBA',(W+pad*2, H+6),(0,0,0,0))
        yb = round(bob*math.sin(phase))
        for y in range(H):
            t = y/(H-1)
            dx = round(amp*envelope(kind,t)*math.sin(2*math.pi*y/wl - phase))
            row = src.crop((0,y,W,y+1))
            canvas.alpha_composite(row,(pad+dx, y+3+yb))
        frames.append(canvas)
    return frames

variants = {
 'A_baseline_amp6_head':      make2(6, 26, 'head'),
 'B_amp11_planted_wl30':      make2(11,30, 'planted'),
 'C_amp13_planted_wl22':      make2(13,22, 'planted'),
 'D_amp12_midpeak_wl26_bob2': make2(12,26, 'midpeak', bob=2),
}

# build a labeled grid: each row = variant (8 frames), scaled x4
SCALE=4
bg=(40,42,54,255)
cellw = max(f.width for v in variants.values() for f in v)
cellh = max(f.height for v in variants.values() for f in v)
gap=6
rows=len(variants)
gridw = (cellw*NF + gap*(NF+1))
gridh = (cellh*rows + gap*(rows+1))
grid = Image.new('RGBA',(gridw,gridh),bg)
for ri,(name,frames) in enumerate(variants.items()):
    for ci,fr in enumerate(frames):
        x = gap + ci*(cellw+gap) + (cellw-fr.width)//2
        y = gap + ri*(cellh+gap)
        grid.alpha_composite(fr,(x,y))
grid = grid.resize((gridw*SCALE, gridh*SCALE), Image.NEAREST)
grid.save('slither_variants.png')
print('grid', grid.size, 'cell', cellw, cellh)

# also GIFs for the two best candidates
for name in ['B_amp11_planted_wl30','C_amp13_planted_wl22','D_amp12_midpeak_wl26_bob2']:
    frs=[f.resize((f.width*SCALE,f.height*SCALE),Image.NEAREST) for f in variants[name]]
    # flatten onto bg for gif
    flat=[Image.alpha_composite(Image.new('RGBA',f.size,bg),f).convert('P',palette=Image.ADAPTIVE) for f in frs]
    flat[0].save(f'gif_{name}.gif', save_all=True, append_images=flat[1:], duration=90, loop=0, disposal=2)
    print('gif_'+name)
