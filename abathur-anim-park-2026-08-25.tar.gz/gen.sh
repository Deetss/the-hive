#!/usr/bin/env bash
set -uo pipefail
cd "$(dirname "$0")"
TOKEN=$(az account get-access-token --scope "https://cognitiveservices.azure.com/.default" --query accessToken -o tsv 2>/dev/null)
URL="${FLUX_HOST}/providers/blackforestlabs/v1/flux-2-pro?api-version=preview"
gen() {
  local name="$1"; local prompt="$2"
  local body=$(jq -n --arg p "$prompt" '{model:"FLUX.2-pro", prompt:$p, width:1024, height:1024, output_format:"png"}')
  local code=$(curl -s -w "%{http_code}" -o "r_$name.json" -X POST "$URL" -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" --data "$body" --max-time 150)
  if [ "$code" = "200" ]; then
    jq -r '.data[0].b64_json' "r_$name.json" | base64 -d > "ref-$name.png"
    echo "$name: OK ($(du -h ref-$name.png|cut -f1))"
  else echo "$name: HTTP $code $(head -c 160 r_$name.json|tr '\n' ' ')"; fi
}
STYLE="clean pixel art game sprite, glowing amber eyes, bony spikes, front view, flat charcoal background, limited palette, no text, no watermark"
gen abathur   "A StarCraft-style Zerg evolution master Abathur, hunched serpentine creature, sickly yellow-green chitin carapace, many small glowing amber eyes, whip-like tendrils, a bladed tail, no legs, $STYLE"
gen overlord  "A StarCraft-style Zerg Overlord, large floating bloated creature, violet purple membranous carapace, gas sacs, dangling tentacles, hovering, $STYLE"
gen hydralisk "A StarCraft-style Zerg Hydralisk, tall upright serpentine creature, green chitin carapace, dorsal spines, scythe forelimbs, $STYLE"
