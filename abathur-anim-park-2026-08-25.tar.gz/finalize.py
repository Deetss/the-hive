import math
from PIL import Image
im=Image.open('abathur-ref.png').convert('RGBA'); W,H=im.size; px=im.load()
BG=(239,9,198)
def is_bg(r,g,b):
    return (abs(r-BG[0])<40 and abs(g-BG[1])<45 and abs(b-BG[2])<45) or (r>195 and g<70 and b>150)
for y in range(H):
    for x in range(W):
        r,g,b,a=px[x,y]
        if is_bg(r,g,b): px[x,y]=(0,0,0,0)
im=im.crop(im.getbbox())
# trim widest blade tips: 7% off each side
cw=int(im.width*0.07); im=im.crop((cw,0,im.width-cw,im.height))
TH=46; tw=round(im.width*TH/im.height)
sprite=im.resize((tw,TH),Image.LANCZOS); sp=sprite.load()
for y in range(TH):
    for x in range(tw):
        r,g,b,a=sp[x,y]
        if is_bg(r,g,b): a=0
        sp[x,y]=(r,g,b,0 if a<115 else 255)
sprite.save('abathur_ship.png'); print('ship sprite',sprite.size)

AMP=7; WL=30
def env(t): return 1-t**3
def frames(nf=8):
    W,H=sprite.size; pad=AMP+2; out=[]
    for f in range(nf):
        ph=2*math.pi*f/nf
        c=Image.new('RGBA',(W+pad*2,H+4),(0,0,0,0))
        for y in range(H):
            t=y/(H-1); dx=round(AMP*env(t)*math.sin(2*math.pi*y/WL-ph))
            c.alpha_composite(sprite.crop((0,y,W,y+1)),(pad+dx,y+2))
        out.append(c)
    return out
fr=frames()
S=5;bg=(40,42,54,255);NF=8;gap=6
cw2=max(f.width for f in fr);ch2=max(f.height for f in fr)
gw=cw2*NF+gap*(NF+1);grid=Image.new('RGBA',(gw,ch2+2*gap),bg)
for ci,f in enumerate(fr): grid.alpha_composite(f,(gap+ci*(cw2+gap)+(cw2-f.width)//2,gap))
grid=grid.resize((gw*S,(ch2+2*gap)*S),Image.NEAREST);grid.save('ship_strip.png');print('strip',grid.size)
flat=[Image.alpha_composite(Image.new('RGBA',(f.width*S,f.height*S),bg),f.resize((f.width*S,f.height*S),Image.NEAREST)).convert('P',palette=Image.ADAPTIVE) for f in fr]
flat[0].save('ship.gif',save_all=True,append_images=flat[1:],duration=85,loop=0,disposal=2)
